use library;
fn main() {
    library::student::information::data();
}
