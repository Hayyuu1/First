


mod lib;
fn main() {
    lib::student::information::data();
    
}
